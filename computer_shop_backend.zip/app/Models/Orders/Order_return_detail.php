<?php

namespace App\Models\Orders;

use Illuminate\Database\Eloquent\Model;

class Order_return_detail extends Model
{
    //
}
